package Dao;

import Model.AdminM;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDao {

    private String jdbcUrl = "jdbc:postgresql://localhost:5432/gym_membership_system_db";
    private String dbusername = "postgres";
    private String dbpasswd = "123";

    public int createAdmin(AdminM admin) {
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
            String sql = "INSERT INTO admin(id,name,phone,role,password) VALUES(?,?,?,?,?) ";
            PreparedStatement prst = con.prepareStatement(sql);
            prst.setInt(1, admin.getId());
            prst.setString(2, admin.getName());
            prst.setInt(3, admin.getPhone());
            prst.setString(4, admin.getRole());
            prst.setString(5, admin.getPassword());
            int rowAffected = prst.executeUpdate();
            con.close();
            return rowAffected;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String authentication(AdminM admin) {
        String role = null;
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
            String sql = "SELECT role FROM admin WHERE id = ? AND password = ?";
            PreparedStatement prst = con.prepareStatement(sql);
            prst.setInt(1, admin.getId());
            prst.setString(2, admin.getPassword());
            ResultSet rs = prst.executeQuery();
            if (rs.next()) {
                role = rs.getString("role");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return role;
    }

    public AdminM searchAdmin(int id) {
        AdminM admin = null;
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
            String sql = "SELECT * FROM admin WHERE id = ?";
            PreparedStatement prst = con.prepareStatement(sql);
            prst.setInt(1, id);
            ResultSet rs = prst.executeQuery();
            if (rs.next()) {
                admin = new AdminM();
                admin.setId(rs.getInt("id"));
                admin.setName(rs.getString("name"));
                admin.setPhone(rs.getInt("phone"));
                admin.setRole(rs.getString("role"));
                admin.setPassword(rs.getString("password"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return admin;
    }

    public int deleteAdmin(int id) {
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
            String sql = "DELETE FROM admin WHERE id = ?";
            PreparedStatement prst = con.prepareStatement(sql);
            prst.setInt(1, id);
            int rowAffected = prst.executeUpdate();
            con.close();
            return rowAffected;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateAdmin(AdminM admin) {
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
            String sql = "UPDATE admin SET name=?, phone=?, role=?, password=? WHERE id=?";
            PreparedStatement prst = con.prepareStatement(sql);
            prst.setString(1, admin.getName());
            prst.setInt(2, admin.getPhone());
            prst.setString(3, admin.getRole());
            prst.setString(4, admin.getPassword());
            prst.setInt(5, admin.getId());
            int rowAffected = prst.executeUpdate();
            con.close();
            return rowAffected;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean updatePassword(AdminM admin){
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
            String sql = "UPDATE admin SET password = ? WHERE id = ?";
            PreparedStatement prst = con.prepareStatement(sql);
            prst.setString(1, admin.getPassword());
            prst.setInt(2, admin.getId());
            int rowAffected = prst.executeUpdate();
            con.close();
            return rowAffected > 0;
            
        } catch (Exception e) {e.printStackTrace();
        }
        return false;
    
      
    
    
    
}
}