/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.MemberM;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Divin
 */
public class MemberDao {
    
    
    
    private String jdbcUrl = "jdbc:postgresql://localhost:5432/gym_membership_system_db";
    private String dbusername = "postgres";
    private String dbpasswd = "123";
    
    
   public int createMember(MemberM member){
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
        String sql = "INSERT INTO member(id,name,phone,gender,age,subscription) VALUES(?,?,?,?,?,?) ";
        PreparedStatement prst = con.prepareStatement(sql);
        prst.setInt(1,member.getId());
        prst.setString(2,member.getName());
        prst.setInt(3,member.getPhone());
        prst.setString(4,member.getGender());
        prst.setInt(5,member.getAge());
        prst.setString(6,member.getSubscription());
        int rowAffected = prst.executeUpdate();
        con.close();
        return rowAffected;
        
           
       } catch (Exception e) { e.printStackTrace();
       }
        return 0;
  
   }
   
   // Add a method to search for a member by ID
    public MemberM getMemberById(int memberId) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        MemberM member = null;
        
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd); // Obtain your database connection
            String query = "SELECT * FROM member WHERE id = ?";
            stmt = con.prepareStatement(query);
            stmt.setInt(1, memberId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Retrieve member details from the result set and create a MemberM object
                member = new MemberM(rs.getInt("id"), rs.getString("name"), rs.getInt("phone"),
                                      rs.getString("gender"), rs.getInt("age"), rs.getString("subscription"));
            }
        } finally {
            // Close resources in the finally block
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
        
        return member;
    }
   public int deleteMemberById(int memberId) throws SQLException {
    try (Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd)) {
        String sql = "DELETE FROM member WHERE id = ?";
        try (PreparedStatement prst = con.prepareStatement(sql)) {
            prst.setInt(1, memberId);
            return prst.executeUpdate();
        }
    }
}
public int updateMember(MemberM member) throws SQLException {
    try (Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd)) {
        String sql = "UPDATE member SET name=?, phone=?, gender=?, age=?, subscription=? WHERE id=?";
        try (PreparedStatement prst = con.prepareStatement(sql)) {
            prst.setString(1, member.getName());
            prst.setInt(2, member.getPhone());
            prst.setString(3, member.getGender());
            prst.setInt(4, member.getAge());
            prst.setString(5, member.getSubscription());
            prst.setInt(6, member.getId());
            return prst.executeUpdate();
        }
    }
}

   

    public List<MemberM> retrieveAllMembers() {
        List<MemberM> memberList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd); // Obtain your database connection
            String query = "SELECT * FROM member";
            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                // Retrieve member details from the result set and create a MemberM object for each row
                MemberM member = new MemberM(rs.getInt("id"), rs.getString("name"), rs.getInt("phone"),
                                             rs.getString("gender"), rs.getInt("age"), rs.getString("subscription"));
                memberList.add(member);
            }
        } catch (SQLException e) {
            // Handle or log the exception appropriately
            e.printStackTrace();
        } finally {
            // Close resources in the finally block
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                // Handle or log the exception appropriately
                e.printStackTrace();
            }
        }
        
        return memberList;
    }
}

    

