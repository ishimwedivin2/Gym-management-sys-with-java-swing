/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.PaymentM;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Divin
 */
public class PaymentDao {
    
    private String jdbcUrl = "jdbc:postgresql://localhost:5432/gym_membership_system_db";
    private String dbusername = "postgres";
    private String dbpasswd = "123";
    
 public int createPayment(PaymentM payment) {
    try {
        Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
        String sql = "INSERT INTO payment(id, name, transaction_id, amount, subscription) VALUES(?, ?, ?, ?, ?)";
        PreparedStatement prst = con.prepareStatement(sql);

        prst.setInt(1, payment.getId());
        prst.setString(2, payment.getName());
        prst.setInt(3, payment.getTransactionId());
        prst.setDouble(4, payment.getAmount());
        prst.setString(5, payment.getSubscription());

        int rowAffected = prst.executeUpdate();

        // Close PreparedStatement and Connection
        prst.close();
        con.close();

        return rowAffected;

    } catch (Exception e) {
        e.printStackTrace();
        return 0; // Return 0 if an exception occurs
    }
    
    
    
}
    
}



