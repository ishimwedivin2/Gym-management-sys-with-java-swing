package Dao;

import Model.TrainerM;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TrainerDao {
    private String jdbcUrl = "jdbc:postgresql://localhost:5432/gym_membership_system_db";
    private String dbusername = "postgres";
    private String dbpasswd = "123";

    public int createTrainer(TrainerM trainer) {
        try (Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd)) {
            String sql = "INSERT INTO trainer(id, name, phone, specialization, yearsofexperience, password) VALUES(?,?,?,?,?,?)";
            try (PreparedStatement prst = con.prepareStatement(sql)) {
                prst.setInt(1, trainer.getId());
                prst.setString(2, trainer.getName());
                prst.setInt(3, trainer.getPhone());
                prst.setString(4, trainer.getSpecialization());
                prst.setInt(5, trainer.getYearsofexperience());
                prst.setString(6, trainer.getPassword());
                return prst.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public TrainerM getTrainerById(int trainerId) throws SQLException {
        TrainerM trainer = null;
        try (Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd)) {
            String query = "SELECT * FROM trainer WHERE id = ?";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setInt(1, trainerId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        trainer = new TrainerM(rs.getInt("id"), rs.getString("name"), rs.getInt("phone"),
                                rs.getString("specialization"), rs.getInt("yearsofexperience"), rs.getString("password"));
                    }
                }
            }
        }
        return trainer;
    }

    public int deleteTrainerById(int trainerId) throws SQLException {
        try (Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd)) {
            String sql = "DELETE FROM trainer WHERE id = ?";
            try (PreparedStatement prst = con.prepareStatement(sql)) {
                prst.setInt(1, trainerId);
                return prst.executeUpdate();
            }
        }
    }

    public int updateTrainer(TrainerM trainer) throws SQLException {
        try (Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd)) {
            String sql = "UPDATE trainer SET name=?, phone=?, specialization=?, yearsofexperience=?, password=? WHERE id=?";
            try (PreparedStatement prst = con.prepareStatement(sql)) {
                prst.setString(1, trainer.getName());
                prst.setInt(2, trainer.getPhone());
                prst.setString(3, trainer.getSpecialization());
                prst.setInt(4, trainer.getYearsofexperience());
                prst.setString(5, trainer.getPassword());
                prst.setInt(6, trainer.getId());
                return prst.executeUpdate();
            }
        }
    }
    
    

    public List<TrainerM> retrievealltrainers(){
        try {
            Connection con = DriverManager.getConnection(jdbcUrl, dbusername, dbpasswd);
            String sql = "SELECT id,name,phone,specialization,yearsofexperience,password FROM trainer";
            PreparedStatement prst = con.prepareStatement(sql);
            ResultSet rs = prst.executeQuery();
            List<TrainerM> trainerlist = new ArrayList<>();
            while (rs.next()){
            TrainerM trainerls = new TrainerM();
            trainerls.setId(rs.getInt("id"));
            trainerls.setName(rs.getString("name"));
            trainerls.setPhone(rs.getInt("phone"));
            trainerls.setSpecialization(rs.getString("specialization"));
            trainerls.setYearsOfExperience(rs.getInt("yearsofexperience"));
            trainerls.setPassword(rs.getString("password"));
            trainerlist.add(trainerls);  
            }
            con.close();
            return trainerlist;

        } catch (Exception e)
        {e.printStackTrace();}
        return null;
    
    }
    
    
    
    
    
}
