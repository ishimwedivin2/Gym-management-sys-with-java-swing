package Model;

import java.util.Objects;

public class AdminM {

    public AdminM() {
    }

    private int id;
    private String password;
    private String name;
    private int phone;
    private String role;

    public AdminM(int id, String password, String name, int phone, String role) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdminM admin = (AdminM) o;
        return id == admin.id &&
                phone == admin.phone &&
                Objects.equals(password, admin.password) &&
                Objects.equals(name, admin.name) &&
                Objects.equals(role, admin.role);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, password, name, phone, role);
    }

    @Override
    public String toString() {
        return "AdminM{" +
                "id=" + id +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", phone=" + phone +
                ", role='" + role + '\'' +
                '}';
    }
    
    

    public void update(String password, String name, int phone, String role) {
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.role = role;
    }

    
    
}
