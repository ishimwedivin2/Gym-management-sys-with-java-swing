/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Dao.MemberDao;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Divin
 */
public class MemberM {
    
    public MemberM() {
    }
    
  private int id;
    private String name;
    private int phone;
    private String gender;
    private int age;
    private String subscription;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSubscription() {
        return subscription;
    }

    public void setSubscription(String subscription) {
        this.subscription = subscription;
    }

    public MemberM(int id, String name, int phone, String gender, int age, String subscription) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.gender = gender;
        this.age = age;
        this.subscription = subscription;
    }
    
    
    // Add a static method to search for a member by ID
    public static MemberM searchMemberById(int memberId) {
        MemberM member = null;
        
        try {
            // Call the DAO method to retrieve member details
            MemberDao memberDao = new MemberDao();
            member = memberDao.getMemberById(memberId);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
        
        return member;
    }
    public static int deleteMemberById(int memberId) {
    int rowsAffected = 0;
    
    try {
        // Call the DAO method to delete the member
        MemberDao memberDao = new MemberDao();
        rowsAffected = memberDao.deleteMemberById(memberId);
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle the exception as needed
    }
    
    return rowsAffected;
}

    public static int updateMember(MemberM member) {
    int rowsAffected = 0;
    
    try {
        // Call the DAO method to update the member
        MemberDao memberDao = new MemberDao();
        rowsAffected = memberDao.updateMember(member);
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle the exception as needed
    }
    
    return rowsAffected;
}
    public static List<MemberM> retrieveAllMembers() {
        List<MemberM> memberList = null;
        
        // Call the DAO method to retrieve all members
        MemberDao memberDao = new MemberDao();
        memberList = memberDao.retrieveAllMembers();
        
        return memberList;
    
    
    

    }   
}
