package Model;

public class PaymentM {
    private int id;
    private String name;
    private int transactionId;
    private double amount;
    private String subscription;

    public PaymentM() {
        // Default constructor
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getSubscription() {
        return subscription;
    }

    public void setSubscription(String subscription) {
        this.subscription = subscription;
    }

    public PaymentM(int id, String name, int transactionId, double amount, String subscription) {
        this.id = id;
        this.name = name;
        this.transactionId = transactionId;
        this.amount = amount;
        this.subscription = subscription;
    }   
}
