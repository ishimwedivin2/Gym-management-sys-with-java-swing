package Model;

import Dao.TrainerDao;
import java.sql.SQLException;

public class TrainerM {
    private int id;
    private String name;
    private int phone;
    private String specialization;
    private int yearsofexperience;
    private String password;

    public TrainerM() {}

    public TrainerM(int id, String name, int phone, String specialization, int yearsofexperience, String password) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.specialization = specialization;
        this.yearsofexperience = yearsofexperience;
        this.password = password;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public int getYearsofexperience() {
        return yearsofexperience;
    }

    public void setYearsOfExperience(int yearsofexperience) {
        this.yearsofexperience = yearsofexperience;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    

    public static TrainerM searchTrainerById(int trainerId) {
        TrainerM trainer = null;
        try {
            TrainerDao trainerDao = new TrainerDao();
            trainer = trainerDao.getTrainerById(trainerId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return trainer;
    }

    public static int deleteTrainerById(int trainerId) {
        int rowsAffected = 0;
        try {
            TrainerDao trainerDao = new TrainerDao();
            rowsAffected = trainerDao.deleteTrainerById(trainerId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowsAffected;
    }

    public static int updateTrainer(TrainerM trainer) {
        int rowsAffected = 0;
        try {
            TrainerDao trainerDao = new TrainerDao();
            rowsAffected = trainerDao.updateTrainer(trainer);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowsAffected;
    }
}
